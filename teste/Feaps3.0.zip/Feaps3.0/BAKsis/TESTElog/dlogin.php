<?php
include('conexao.php');

if(isset($_POST['user']) || isset($_POST['senha'])){

    if(strlen($_POST['user'])==0){
        echo "Preencha o user";
    } else if(isset($_POST['senha'])==0){
        echo "Preencha a senha";
    }else{

        $user =$con->real_escape_string($_POST['user']);
        $senha =$con->real_escape_string($_POST['senha']);

        $sql_code = "SELECT * FROM jurados WHERE usuario='$user' AND senha='$senha'";
        $sql_query =$con->query($sql_code) or die("falha na execução" .$con->error);
        
        $quantidade = $sql_query->num_rows;

        if($quantidade==1){

            $usuario = $sql_query->fetch_assoc();

            if(!isset($_SESSION)) {
                session_start();
            }

            $_SESSION['ID'] = $usuario['ID'];

            header("Location: avaliar.php");
        }else{
            echo "falha ao logar!";
        }
    }
}
?>
