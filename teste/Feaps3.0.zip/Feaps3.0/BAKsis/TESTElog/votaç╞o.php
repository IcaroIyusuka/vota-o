<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votação Jeans</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
<form method="post" action="dados.php">  
<div class="row row-cols-1 row-cols-md-5 g-3">
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>

<input type="radio" class="btn-check" name="nota" id="b1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="b1">1</label>

<input type="radio" class="btn-check" name="nota" id="b2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="b2">2</label>

<input type="radio" class="btn-check" name="nota" id="b3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="b3">3</label>

<input type="radio" class="btn-check" name="nota" id="b4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="b4">4</label>

<input type="radio" class="btn-check" name="nota" id="b5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="b5">5</label>

<input type="radio" class="btn-check" name="nota" id="b6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="b6">6</label>

<input type="radio" class="btn-check" name="nota" id="b7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="b7">7</label>

<input type="radio" class="btn-check" name="nota" id="b8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="b8">8</label>

<input type="radio" class="btn-check" name="nota" id="b9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="b9">9</label>

<input type="radio" class="btn-check" name="nota" id="b10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="b10">10</label>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="not" id="t1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="t1">1</label>

<input type="radio" class="btn-check" name="not" id="t2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="t2">2</label>

<input type="radio" class="btn-check" name="not" id="t3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="t3">3</label>

<input type="radio" class="btn-check" name="not" id="t4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="t4">4</label>

<input type="radio" class="btn-check" name="not" id="t5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="t5">5</label>

<input type="radio" class="btn-check" name="not" id="t6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="t6">6</label>

<input type="radio" class="btn-check" name="not" id="t7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="t7">7</label>

<input type="radio" class="btn-check" name="not" id="t8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="t8">8</label>

<input type="radio" class="btn-check" name="not" id="t9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="t9">9</label>

<input type="radio" class="btn-check" name="not" id="t10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="t10">10</label>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="no" id="n1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="n1">1</label>

<input type="radio" class="btn-check" name="no" id="n2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="n2">2</label>

<input type="radio" class="btn-check" name="no" id="n3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="n3">3</label>

<input type="radio" class="btn-check" name="no" id="n4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="n4">4</label>

<input type="radio" class="btn-check" name="no" id="n5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="n5">5</label>

<input type="radio" class="btn-check" name="no" id="n6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="n6">6</label>

<input type="radio" class="btn-check" name="no" id="n7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="n7">7</label>

<input type="radio" class="btn-check" name="no" id="n8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="n8">8</label>

<input type="radio" class="btn-check" name="no" id="n9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="n9">9</label>

<input type="radio" class="btn-check" name="no" id="n10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="n10">10</label>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="nt" id="a1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="a1">1</label>

<input type="radio" class="btn-check" name="nt" id="a2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="a2">2</label>

<input type="radio" class="btn-check" name="nt" id="a3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="a3">3</label>

<input type="radio" class="btn-check" name="nt" id="a4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="a4">4</label>

<input type="radio" class="btn-check" name="nt" id="a5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="a5">5</label>

<input type="radio" class="btn-check" name="nt" id="a6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="a6">6</label>

<input type="radio" class="btn-check" name="nt" id="a7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="a7">7</label>

<input type="radio" class="btn-check" name="nt" id="a8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="a8">8</label>

<input type="radio" class="btn-check" name="nt" id="a9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="a9">9</label>

<input type="radio" class="btn-check" name="nt" id="a10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="a10">10</label>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="a" id="c1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="c1">1</label>

<input type="radio" class="btn-check" name="a" id="c2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="c2">2</label>

<input type="radio" class="btn-check" name="a" id="c3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="c3">3</label>

<input type="radio" class="btn-check" name="a" id="c4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="c4">4</label>

<input type="radio" class="btn-check" name="a" id="c5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="c5">5</label>

<input type="radio" class="btn-check" name="a" id="c6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="c6">6</label>

<input type="radio" class="btn-check" name="a" id="c7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="c7">7</label>

<input type="radio" class="btn-check" name="a" id="c8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="c8">8</label>

<input type="radio" class="btn-check" name="a" id="c9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="c9">9</label>

<input type="radio" class="btn-check" name="a" id="c10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="c10">10</label>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="c" id="d1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="d1">1</label>

<input type="radio" class="btn-check" name="c" id="d2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="d2">2</label>

<input type="radio" class="btn-check" name="c" id="d3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="d3">3</label>

<input type="radio" class="btn-check" name="c" id="d4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="d4">4</label>

<input type="radio" class="btn-check" name="c" id="d5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="d5">5</label>

<input type="radio" class="btn-check" name="c" id="d6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="d6">6</label>

<input type="radio" class="btn-check" name="c" id="d7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="d7">7</label>

<input type="radio" class="btn-check" name="c" id="d8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="d8">8</label>

<input type="radio" class="btn-check" name="c" id="d9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="d9">9</label>

<input type="radio" class="btn-check" name="c" id="d10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="d10">10</label> 
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="d" id="e1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="e1">1</label>

<input type="radio" class="btn-check" name="d" id="e2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="e2">2</label>

<input type="radio" class="btn-check" name="d" id="e3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="e3">3</label>

<input type="radio" class="btn-check" name="d" id="e4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="e4">4</label>

<input type="radio" class="btn-check" name="d" id="e5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="e5">5</label>

<input type="radio" class="btn-check" name="d" id="e6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="e6">6</label>

<input type="radio" class="btn-check" name="d" id="e7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="e7">7</label>

<input type="radio" class="btn-check" name="d" id="e8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="e8">8</label>

<input type="radio" class="btn-check" name="d" id="e9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="e9">9</label>

<input type="radio" class="btn-check" name="d" id="e10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="e10">10</label>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="e" id="f1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="f1">1</label>

<input type="radio" class="btn-check" name="e" id="f2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="f2">2</label>

<input type="radio" class="btn-check" name="e" id="f3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="f3">3</label>

<input type="radio" class="btn-check" name="e" id="f4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="f4">4</label>

<input type="radio" class="btn-check" name="e" id="f5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="f5">5</label>

<input type="radio" class="btn-check" name="e" id="f6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="f6">6</label>

<input type="radio" class="btn-check" name="e" id="f7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="f7">7</label>

<input type="radio" class="btn-check" name="e" id="f8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="f8">8</label>

<input type="radio" class="btn-check" name="e" id="f9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="f9">9</label>

<input type="radio" class="btn-check" name="e" id="f10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="f10">10</label>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="f" id="g1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="g1">1</label>

<input type="radio" class="btn-check" name="f" id="g2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="g2">2</label>

<input type="radio" class="btn-check" name="f" id="g3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="g3">3</label>

<input type="radio" class="btn-check" name="f" id="g4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="g4">4</label>

<input type="radio" class="btn-check" name="f" id="g5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="g5">5</label>

<input type="radio" class="btn-check" name="f" id="g6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="g6">6</label>

<input type="radio" class="btn-check" name="f" id="g7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="g7">7</label>

<input type="radio" class="btn-check" name="f" id="g8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="g8">8</label>

<input type="radio" class="btn-check" name="f" id="g9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="g9">9</label>

<input type="radio" class="btn-check" name="f" id="g10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="g10">10</label>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>
        <input type="radio" class="btn-check" name="g" id="h1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="h1">1</label>

<input type="radio" class="btn-check" name="g" id="h2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="h2">2</label>

<input type="radio" class="btn-check" name="g" id="h3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="h3">3</label>

<input type="radio" class="btn-check" name="g" id="h4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="h4">4</label>

<input type="radio" class="btn-check" name="g" id="h5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="h5">5</label>

<input type="radio" class="btn-check" name="g" id="h6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="h6">6</label>

<input type="radio" class="btn-check" name="g" id="h7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="h7">7</label>

<input type="radio" class="btn-check" name="g" id="h8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="h8">8</label>

<input type="radio" class="btn-check" name="g" id="h9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="h9">9</label>

<input type="radio" class="btn-check" name="g" id="h10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="h10">10</label>
      </div>
    </div>
  </div>
</div>
<button type="submit">Avaliar</button>
</form>
</body>
</html>