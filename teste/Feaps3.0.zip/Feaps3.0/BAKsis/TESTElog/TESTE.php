?>

<?php
$n2 = $_POST["not"];

$voto2="INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n2,NOW(), $idjure)";
$res = mysqli_query($con, $voto2);
$linhas = mysqli_affected_rows($con);
?>

<?php
$n3 = $_POST["no"];

$voto3= "INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n3, NOW(), $idjure)";
$res = mysqli_query($con, $voto3);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n4 = $_POST["nt"];

$voto4= "INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n4, NOW(), $idjure)";
$res = mysqli_query($con, $voto4);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n5 = $_POST["a"];

$voto5= "INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n5, NOW(), $idjure)";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n6 = $_POST["c"];

$voto6= "INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n6, NOW(), $idjure)";
$res = mysqli_query($con, $voto6);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n7=$_POST["d"];

$voto7= "INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n7,NOW(), $idjure)
";
$res = mysqli_query($con, $voto7);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n8=$_POST["e"];

$voto8= "INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n8,NOW(), $idjure)";
$res = mysqli_query($con, $voto8);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n9=$_POST["f"];

$voto9= "INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n9, NOW(), $idjure)";
$res = mysqli_query($con, $voto9);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n10=$_POST["g"];

$voto10= "INSERT INTO nt_jeans (IDJEANS, nota, qtd, id_jure) VALUES (NULL, $n10, NOW(), $idjure)";
$res = mysqli_query($con, $voto10);
$linhas = mysqli_affected_rows($con);

?>

<?php