<?php
include("dlogin.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>testes</title>
    <link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
    <h1>acessar</h1>
    <form class="login" action="" method="POST">
        <p>
            <label>user</label>
            <input type="text" name="user">
        </p>
        <p>
            <label>senha</label>
            <input type="password" name="senha">
        </p>
        <p>
            <button type="submit"> Entrar</button>
        </p>
    </form>
</body>
</html>