<?php
session_start();
include("conexao.php");
include("dlogin.php");


$idjure = $_SESSION["ID"];

?>

<?php
$n1 = $_POST["nota"];

$voto1 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n1,$idjure ,1 ,NOW() )";
$res = mysqli_query($con, $voto1);
$linhas = mysqli_affected_rows($con);
?>


<?php
$n2 = $_POST["not"];

$voto2 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n2,$idjure ,2 ,NOW() )";
$res = mysqli_query($con, $voto2);
$linhas = mysqli_affected_rows($con);
?>

<?php
$n3 = $_POST["no"];

$voto3 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n3,$idjure ,3 ,NOW() )";
$res = mysqli_query($con, $voto3);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n4 = $_POST["nt"];

$voto4 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n4,$idjure ,4 ,NOW() )";
$res = mysqli_query($con, $voto4);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n5 = $_POST["a"];

$voto5 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n5,$idjure ,5 ,NOW() )";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n6 = $_POST["c"];

$voto1 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n6,$idjure ,6 ,NOW() )";
$res = mysqli_query($con, $voto1);
$linhas = mysqli_affected_rows($con);
?>


<?php
$n7 = $_POST["d"];

$voto2 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n7,$idjure ,7 ,NOW() )";
$res = mysqli_query($con, $voto2);
$linhas = mysqli_affected_rows($con);
?>

<?php
$n8 = $_POST["e"];

$voto3 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n8,$idjure ,8 ,NOW() )";
$res = mysqli_query($con, $voto3);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n9 = $_POST["f"];

$voto4 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n9,$idjure ,9,NOW() )";
$res = mysqli_query($con, $voto4);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n10 = $_POST["g"];

$voto5 = "INSERT INTO voto (IDvoto, ntjeans, id_jure, id_part,qnd) VALUES (NULL, $n10,$idjure ,10 ,NOW() )";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);

?>


<?php

if ($linhas == 1) {
} else {
  echo "falha";
}

mysqli_close($con);
?>
<?
include("dados.php")
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Votação Social</title>
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<body>
  <form method="post" action="VotarTipica.php">
    <div class="row row-cols-1 row-cols-md-5 g-3">
      <div class="col">
        <div class="card h-100">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">2°Etapa Traje Social</h5>
            <p class="card-text">Tayna Brisola</p>

            <input type="radio" class="btn-check " name="nota" id="b1" value="1" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="b1">1</label>

            <input type="radio" class="btn-check " name="nota" id="b2" value="2" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="b2">2</label>

            <input type="radio" class="btn-check " name="nota" id="b3" value="3" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="b3">3</label>

            <input type="radio" class="btn-check " name="nota" id="b4" value="4" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="b4">4</label>

            <input type="radio" class="btn-check " name="nota" id="b5" value="5" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="b5">5</label>

          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">2°Etapa Traje Social</h5>
            <p class="card-text">Nicole Layane</p>
            <input type="radio" class="btn-check " name="not" id="t1" value="1" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="t1">1</label>

            <input type="radio" class="btn-check " name="not" id="t2" value="2" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="t2">2</label>

            <input type="radio" class="btn-check " name="not" id="t3" value="3" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="t3">3</label>

            <input type="radio" class="btn-check " name="not" id="t4" value="4" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="t4">4</label>

            <input type="radio" class="btn-check " name="not" id="t5" value="5" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="t5">5</label>



          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">2°Etapa Traje Social</h5>
            <p class="card-text">Nahida Monik</p>
            <input type="radio" class="btn-check " name="no" id="n1" value="1" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="n1">1</label>

            <input type="radio" class="btn-check " name="no" id="n2" value="2" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="n2">2</label>

            <input type="radio" class="btn-check " name="no" id="n3" value="3" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="n3">3</label>

            <input type="radio" class="btn-check " name="no" id="n4" value="4" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="n4">4</label>

            <input type="radio" class="btn-check " name="no" id="n5" value="5" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="n5">5</label>


          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">2°Etapa Traje Social</h5>
            <p class="card-text">Yasmin Domingues</p>
            <input type="radio" class="btn-check " name="nt" id="a1" value="1" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="a1">1</label>

            <input type="radio" class="btn-check " name="nt" id="a2" value="2" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="a2">2</label>

            <input type="radio" class="btn-check " name="nt" id="a3" value="3" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="a3">3</label>

            <input type="radio" class="btn-check " name="nt" id="a4" value="4" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="a4">4</label>

            <input type="radio" class="btn-check " name="nt" id="a5" value="5" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="a5">5</label>

          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">2°Etapa Traje Social</h5>
            <p class="card-text">Kamile da Silva</p>
            <input type="radio" class="btn-check " name="a" id="c1" value="1" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="c1">1</label>

            <input type="radio" class="btn-check " name="a" id="c2" value="2" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="c2">2</label>

            <input type="radio" class="btn-check " name="a" id="c3" value="3" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="c3">3</label>

            <input type="radio" class="btn-check " name="a" id="c4" value="4" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="c4">4</label>

            <input type="radio" class="btn-check " name="a" id="c5" value="5" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="c5">5</label>


          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">2°Etapa Traje Social</h5>
            <p class="card-text">Nicoly Canuti</p>
            <input type="radio" class="btn-check " name="c" id="d1" value="1" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="d1">1</label>

            <input type="radio" class="btn-check " name="c" id="d2" value="2" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="d2">2</label>

            <input type="radio" class="btn-check " name="c" id="d3" value="3" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="d3">3</label>

            <input type="radio" class="btn-check " name="c" id="d4" value="4" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="d4">4</label>

            <input type="radio" class="btn-check " name="c" id="d5" value="5" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="d5">5</label>


          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">2°Etapa Traje Social</h5>
            <p class="card-text">Alanys Leal</p>
            <input type="radio" class="btn-check " name="d" id="e1" value="1" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="e1">1</label>

            <input type="radio" class="btn-check " name="d" id="e2" value="2" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="e2">2</label>

            <input type="radio" class="btn-check " name="d" id="e3" value="3" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="e3">3</label>

            <input type="radio" class="btn-check " name="d" id="e4" value="4" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="e4">4</label>

            <input type="radio" class="btn-check " name="d" id="e5" value="5" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="e5">5</label>

          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">2°Etapa Traje Social</h5>
            <p class="card-text">Gabrielli Garcia</p>
            <input type="radio" class="btn-check " name="e" id="f1" value="1" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="f1">1</label>

            <input type="radio" class="btn-check " name="e" id="f2" value="2" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="f2">2</label>

            <input type="radio" class="btn-check " name="e" id="f3" value="3" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="f3">3</label>

            <input type="radio" class="btn-check " name="e" id="f4" value="4" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="f4">4</label>

            <input type="radio" class="btn-check " name="e" id="f5" value="5" autocomplete="off" required="required">
            <label class="btn btn-outline-primary " for="f5">5</label>
          </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">2°Etapa Traje Social</h5>
              <p class="card-text">Jennifer Almeida</p>
              <input type="radio" class="btn-check " name="f" id="g1" value="1" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="g1">1</label>

              <input type="radio" class="btn-check " name="f" id="g2" value="2" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="g2">2</label>

              <input type="radio" class="btn-check " name="f" id="g3" value="3" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="g3">3</label>

              <input type="radio" class="btn-check " name="f" id="g4" value="4" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="g4">4</label>

              <input type="radio" class="btn-check " name="f" id="g5" value="5" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="g5">5</label>

            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">2°Etapa Traje Social</h5>
              <p class="card-text">Isaelem Reysa</p>
              <input type="radio" class="btn-check " name="g" id="h1" value="1" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="h1">1</label>

              <input type="radio" class="btn-check " name="g" id="h2" value="2" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="h2">2</label>

              <input type="radio" class="btn-check " name="g" id="h3" value="3" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="h3">3</label>

              <input type="radio" class="btn-check " name="g" id="h4" value="4" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="h4">4</label>

              <input type="radio" class="btn-check " name="g" id="h5" value="5" autocomplete="off" required="required">
              <label class="btn btn-outline-primary " for="h5">5</label>

            </div>
          </div>
        </div>
      </div>
      <button type="submit">Avaliar</button>
  </form>
  <script type="text/javascript" src="javas.js"></script>
</body>

</html>