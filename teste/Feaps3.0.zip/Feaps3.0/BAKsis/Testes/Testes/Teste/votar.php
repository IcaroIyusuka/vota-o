<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
<form method="post" action="dados.php">  
<div class="row row-cols-1 row-cols-md-5 g-3">
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text"></p>

<input type="radio" class="btn-check" name="nota" id="b1" value="1" autocomplete="off">
<label class="btn btn-outline-primary" for="b1">1</label>

<input type="radio" class="btn-check" name="nota" id="b2" value="2" autocomplete="off">
<label class="btn btn-outline-primary" for="b2">2</label>

<input type="radio" class="btn-check" name="nota" id="b3" value="3" autocomplete="off">
<label class="btn btn-outline-primary" for="b3">3</label>

<input type="radio" class="btn-check" name="nota" id="b4" value="4" autocomplete="off">
<label class="btn btn-outline-primary" for="b4">4</label>

<input type="radio" class="btn-check" name="nota" id="b5" value="5" autocomplete="off">
<label class="btn btn-outline-primary" for="b5">5</label>

<input type="radio" class="btn-check" name="nota" id="b6" value="6" autocomplete="off">
<label class="btn btn-outline-primary" for="b6">6</label>

<input type="radio" class="btn-check" name="nota" id="b7" value="7" autocomplete="off">
<label class="btn btn-outline-primary" for="b7">7</label>

<input type="radio" class="btn-check" name="nota" id="b8" value="8" autocomplete="off">
<label class="btn btn-outline-primary" for="b8">8</label>

<input type="radio" class="btn-check" name="nota" id="b9" value="9" autocomplete="off">
<label class="btn btn-outline-primary" for="b9">9</label>

<input type="radio" class="btn-check" name="nota" id="b10" value="10" autocomplete="off">
<label class="btn btn-outline-primary" for="b10">10</label>
      </div>
    </div>
  </div>
  <button type="submit">Avaliar</button>
</form>
</body>
</html>