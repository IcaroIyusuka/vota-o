<?php
session_start();
include("conexao.php");
include("dlogin.php");


$idjure=$_SESSION["ID"];
?>

<?php
$n1 = $_POST["nota"];

$voto1 = "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n1,  $idjure, 1,NOW())";
$res = mysqli_query($con, $voto1);
$linhas = mysqli_affected_rows($con);
?>


<?php
$n2 = $_POST["not"];

$voto2="INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n2, $idjure, 2,NOW())";
$res = mysqli_query($con, $voto2);
$linhas = mysqli_affected_rows($con);
?>

<?php
$n3 = $_POST["no"];

$voto3= "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n3,  $idjure, 3,NOW())";
$res = mysqli_query($con, $voto3);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n4 = $_POST["nt"];

$voto4= "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n4,  $idjure, 4,NOW())";
$res = mysqli_query($con, $voto4);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n5 = $_POST["a"];

$voto5= "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n5,  $idjure, 5,NOW())";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n6 = $_POST["c"];

$voto6= "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n6,  $idjure, 6,NOW())";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);

?>


<?php
$n7 = $_POST["d"];

$voto7= "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n7,  $idjure, 7,NOW())";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n8 = $_POST["e"];

$voto8= "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n8,  $idjure, 8,NOW())";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);

?>

<?php
$n9 = $_POST["f"];

$voto9= "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n9,  $idjure, 9,NOW())";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);


?>

<?php
$n10 = $_POST["g"];

$voto10= "INSERT INTO voto (IDvoto, ntsimpatia, id_jure, id_part,qnd) VALUES (NULL, $n10,  $idjure, 10,NOW())";
$res = mysqli_query($con, $voto5);
$linhas = mysqli_affected_rows($con);


?>


<?php

if($linhas==1){
}else{
    echo "falha";
}

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
    <span id="conteudo"></span>
    </div>
        <script>
            $(document).ready(function(){
                $.post('tabela.php', function(retorna){
                    $("#conteudo"). html(retorna);
                });
            });
        </script>
         <script type="text/javascript" src="javas.js"></script>
</body>

</html>

