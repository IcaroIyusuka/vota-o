<?php
include('conexao.php');

$result_nota = "SELECT SUM(voto.ntjeans) AS jeans, 
SUM(voto.ntsocial) AS social,
SUM(voto.nttipica) As tipica,
SUM(voto.ntsimpatia) AS simpatia,
party.nome 
FROM party
INNER JOIN voto ON
voto.id_part=party.IDPAR


GROUP BY party.nome
ORDER BY jeans DESC ";
                
                
$resultado_nota=mysqli_query($con, $result_nota);
?>
<table class="table table-striped table-border">
  <thead>
    <tr>
      
      <th scope="col">1° Etapa jeans</th>
      <th scope="col">2° Etapa gala</th>
      <th scope="col">3° Etapa tipica</th>
      <th scope="col">Simpatia</th>
      <th scope="col">Participante</th>


      <li> <a href="Sair.php">Sair</a></li>
    </tr>
  </thead>
  <tbody>
<?php
if(($resultado_nota) AND ($resultado_nota->num_rows ==0)){
    while($row_nota = mysqli_fetch_assoc($resultado_nota)){
?>
    <tr>
      <th> <?php echo $row_nota ['jeans'] . "<br>"?></th>
      <td> <?php echo $row_nota ['social'] . "<br>"?></td>
      <td> <?php echo $row_nota ['tipica'] . "<br>"?></td>
      <td> <?php echo $row_nota ['simpatia'] . "<br>"?></td>
      <td> <?php echo $row_nota ['party.nome'] . "<br>"?></td>
    </tr>
    <?php
      }
}else{
    echo "nenhuma avaliação";
}
?>
</tbody>
</table>