<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    </head>
    <body>
<div role="group" aria-label="Basic Radio toggle button group">

    <input type="radio" class="btn-check" id="1" name="nota" value="1" autocomplete="off">
    <label class="btn btn-outline-primary" for="1">1</label>

    <input type="radio" class="btn-check" id="2" name="nota" value="2" autocomplete="off">
    <label class="btn btn-outline-primary" for="2">2</label>

    <input type="radio" class="btn-check" id="3" name="nota" value="3" autocomplete="off">
    <label class="btn btn-outline-primary" for="3">3</label>

    <input type="radio" class="btn-check" id="4" name="nota" value="4" autocomplete="off">
    <label class="btn btn-outline-primary" for="4">4</label>

    <input type="radio" class="btn-check" id="5" name="nota" value="5" autocomplete="off">
    <label class="btn btn-outline-primary" for="5">5</label>

    <input type="radio" class="btn-check" id="6" name="nota" value="6" autocomplete="off">
    <label class="btn btn-outline-primary" for="6">6</label>

    <input type="radio" class="btn-check" id="7" name="nota" value="7" autocomplete="off">
    <label class="btn btn-outline-primary" for="7">7</label>

    <input type="radio" class="btn-check" id="8" name="nota" value="8" autocomplete="off">
    <label class="btn btn-outline-primary" for="8">8</label>

    <input type="radio" class="btn-check" id="9" name="nota" value="9" autocomplete="off">
    <label class="btn btn-outline-primary" for="9">9</label>

    <input type="radio" class="btn-check" id="10" name="nota" value="10" autocomplete="off">
    <label class="btn btn-outline-primary" for="10">10</label>


</div>
    </body>
</html>

