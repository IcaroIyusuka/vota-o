<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" cofftent="IE=edge">
    <meta name="viewport" cofftent="width=device-width, initial-scale=1.0">
    <title>Avaliação Jeans</title>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anoffymous">
</head>
<body>
  <form method="POST" action="VotarSocial.php">
<div class="row row-cols-1 row-cols-md-1 g-1">
  <div class="col">
    <div class="card" style="width: 15rem;">
      <img src="teste1.jpg" class="card-img-top" alt="">
      <div class="card-body">
        <h5 class="card-title">1°etapa Traje Jeans</h5>
        <p class="card-text"> Participante</p>
    <div>
    <input type="radio" class=" trav btn-check blok"  id="1" name="nota" value="1" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="1">1</label>

    <input type="radio" class="btn-check blok"  id="2" name="nota" value="2" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="2">2</label>

    <input type="radio" class="btn-check blok"  id="3" name="nota" value="3" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="3">3</label>

    <input type="radio" class="btn-check blok"  id="4" name="nota" value="4" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="4">4</label>

    <input type="radio" class="btn-check blok"  id="5" name="nota" value="5" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="5">5</label>

    <input type="radio" class="btn-check blok"  id="6" name="nota" value="6" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="6">6</label>

    <input type="radio" class="btn-check blok"  id="7" name="nota" value="7" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="7">7</label>

    <input type="radio" class="btn-check blok"  id="8" name="nota" value="8" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="8">8</label>

    <input type="radio" class="btn-check blok"  id="9" name="nota" value="9" autocomplete="off"  >
    <label class="btn-outline-primary btn blok" for="9">9</label>

    <input type="radio" class="btn-check blok"  id="10" name="nota" value="10" autocomplete="off" >
    <label class="btn-outline-primary btn blok" for="10">10</label>
    </div>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">1°Etapa Traje Jeans</h5>
        <p class="card-text">Isaelem Reysa</p>
        <input type="radio" class="btn-check blok1 " name="g" id="h1" value="1" autocomplete="off">
<label class="btn btn-outline-primary blok1 " for="h1">1</label>

<input type="radio" class="btn-check blok1 " name="g" id="h2" value="2" autocomplete="off">
<label class="btn btn-outline-primary blok1  " for="h2">2</label>

<input type="radio" class="btn-check blok1 " name="g" id="h3" value="3" autocomplete="off">
<label class="btn btn-outline-primary blok1 " for="h3">3</label>

<input type="radio" class="btn-check blok1 " name="g" id="h4" value="4" autocomplete="off">
<label class="btn btn-outline-primary blok 1 " for="h4">4</label>

<input type="radio" class="btn-check blok1 " name="g" id="h5" value="5" autocomplete="off">
<label class="btn btn-outline-primary blok 1 " for="h5">5</label>

<input type="radio" class="btn-check blok1 " name="g" id="h6" value="6" autocomplete="off">
<label class="btn btn-outline-primary blok 1 " for="h6">6</label>

<input type="radio" class="btn-check blok1 " name="g" id="h7" value="7" autocomplete="off">
<label class="btn btn-outline-primary blok1  " for="h7">7</label>

<input type="radio" class="btn-check blok1 " name="g" id="h8" value="8" autocomplete="off">
<label class="btn btn-outline-primary blok 1 " for="h8">8</label>

<input type="radio" class="btn-check blok1 " name="g" id="h9" value="9" autocomplete="off">
<label class="btn btn-outline-primary blok 1 " for="h9">9</label>

<input type="radio" class="pda btn-check blok1 " name="g" id="h10" value="10" autocomplete="off">
<label class="btn btn-outline-primary blok1  " for="h10">10</label>
      </div>
    </div>
  </div>
</div>
</div>
</form> 

<script type="text/javascript" src="javas.js"></script>
<script type="text/javascript" src="java.js"></script>
</body>

</html>
