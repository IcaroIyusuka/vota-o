
$(document).ready(function() {
    $(".pda").on("click", function() {
        $(".blok1").prop("realoady", true);
    })
});

$(document).ready(function() {
    $(".pode").on("click", function() {
        $(".blok2").prop('realoady', true);
    })
});
