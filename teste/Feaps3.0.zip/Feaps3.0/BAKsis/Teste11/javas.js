$(document).ready(function() {
    $(".btn-check").on("click", function() {
        $(".h").prop("disabled", true);
    })
});







