<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliar</title>
</head>
<body>
    <form method="post" action="dados.php">
        <label>1°rodada-Estilo Jeans</label>
        <input type="text"  name="notajeans">

        <label>2°rodada-Estilo social</label>
        <input type="text"  name="notasocial">

        <label>3°rodada-Estilo tipica</label>
        <input type="text"  name="notatipica">

        <label>Simpatia</label>
        <input type="text"  name="notasimpatia">

        <input type="submit" value="Avaliar">


    </form>
</body>
</html>