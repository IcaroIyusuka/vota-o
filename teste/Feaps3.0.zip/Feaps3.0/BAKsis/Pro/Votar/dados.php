<?php

include('conexao.php');

$vjeans=$_POST["notajeans"];
$vsocial=$_POST["notasocial"];
$vtipica = $_POST["notatipica"];
$vsimpatia = $_POST["notasimpatia"];

$sql = "INSERT INTO notas VALUES (NULL, $vjeans, $vsocial, $vtipica, $vsimpatia, NULL, NULL )";
$res=mysqli_query($mysqli, $sql);
$linhas = mysqli_affected_rows($mysqli);

if($linhas == 1){
    echo "nota lançada";
}else{
    echo "falha ao lançar a nota";
}

mysqli_close($mysqli);

?>