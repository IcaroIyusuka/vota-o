<?php
include('conexao.php');

$result_nota = "SELECT * FROM notas ORDER BY id DESC";
$resultado_nota=mysqli_query($mysqli, $result_nota);
?>
<table class="table table-striped table-border">
  <thead>
    <tr>
      <th scope="col">Nota jeans</th>
      <th scope="col">Nota social</th>
      <th scope="col">Nota tipica</th>
      <th scope="col">Simpatia</th>
    </tr>
  </thead>
  <tbody>
<?php
if(($resultado_nota) AND ($resultado_nota->num_rows !=0)){
    while($row_nota = mysqli_fetch_assoc($resultado_nota)){
?>
    <tr>
      <th> <?php echo $row_nota ['jeans'] . "<br>"?></th>
      <td> <?php echo $row_nota ['social'] . "<br>"?></td>
      <td> <?php echo $row_nota ['tipica'] . "<br>"?></td>
      <td> <?php echo $row_nota ['simpatia'] . "<br>"?></td>
    </tr>
    <?php
      }
}else{
    echo "nenhuma avaliação";
}
?>
</tbody>
</table>