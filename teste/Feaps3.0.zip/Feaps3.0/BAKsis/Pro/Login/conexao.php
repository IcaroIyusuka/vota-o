<?php
$hostname="localhost";
$username="root";
$senha = "";
$database="feaps";

$mysqli = new mysqli($hostname, $username, $senha, $database);
if($mysqli->connect_errno){
    echo "falha ao conectar";
}
?>