<?php
include('conexao.php');

if(isset($_POST['user']) || isset($_POST['senha'])){

    if(strlen($_POST['user'])==0){
        echo "Preencha o use";
    } else if(isset($_POST['senha'])==0){
        echo "Preencha a senha";
    }else{

        $user = $mysqli->real_escape_string($_POST['user']);
        $senha = $mysqli->real_escape_string($_POST['senha']);

        $sql_code = "SELECT * FROM acesso WHERE user='$user' AND senha='$senha'";
        $sql_query = $mysqli->query($sql_code) or die("falha na execução" . $mysqli->error);
        
        $quantidade = $sql_query->num_rows;

        if($quantidade==1){

            $usuario = $sql_query->fetch_assoc();

            if(!isset($_SESSION)) {
                session_start();
            }

            $_SESSION['id'] = $usuario['id'];

            header("Location:avalia.php");
        }else{
            echo "falha ao logar!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso</title>
</head>
<body>
    <h1>acessar</h1>
    <form action="" method="POST">
        <p>
            <label>user</label>
            <input type="text" name="user">
        </p>
        <p>
            <label>senha</label>
            <input type="password" name="senha">
        </p>
        <p>
            <button type="submit"> Entrar</button>
        </p>
    </form>
</body>
</html>

