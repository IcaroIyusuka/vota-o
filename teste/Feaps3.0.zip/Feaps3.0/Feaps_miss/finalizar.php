<?php

if(!isset($_SESSION)){
    session_start();
}

session_destroy();


?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="icon" type="image/png" href="img/logomultri.png">
        <title>Final</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    
    <script type="text/javascript" src="javas.js"></script>
    </body>
</html>